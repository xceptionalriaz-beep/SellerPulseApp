﻿declare module '*.css'
